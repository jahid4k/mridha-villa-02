"use client";

/**
 * AgreementPDFButton.tsx
 *
 * Drop-in button component for generating and downloading a rental agreement PDF.
 * Place this on your lease detail page / LeaseCard.
 *
 * Props:
 *   leaseId — The MongoDB lease _id string.
 *             The component fetches full lease + tenant + unit data from /api/leases/:id
 *             so you only need to pass the ID.
 *
 * Usage:
 *   <AgreementPDFButton leaseId={lease._id.toString()} generatedBy={session.user.name} />
 */

import { useState } from "react";
import {
  downloadAgreementPDF,
  AgreementData,
} from "@/lib/generateAgreementPDF";

interface AgreementPDFButtonProps {
  leaseId: string;
  generatedBy: string;
  variant?: "primary" | "outline" | "ghost";
  className?: string;
}

// ─── Minimal inline Button styles (replace with your shadcn Button if preferred) ───
const baseBtn =
  "inline-flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-medium transition-all focus:outline-none focus:ring-2 focus:ring-offset-2 disabled:opacity-60 disabled:cursor-not-allowed";

const variants = {
  primary: `${baseBtn} bg-indigo-600 text-white hover:bg-indigo-700 focus:ring-indigo-500`,
  outline: `${baseBtn} border border-indigo-600 text-indigo-600 hover:bg-indigo-50 focus:ring-indigo-500`,
  ghost: `${baseBtn} text-indigo-600 hover:bg-indigo-50 focus:ring-indigo-500`,
};

// ─── Icons ───
const DownloadIcon = () => (
  <svg
    className="w-4 h-4"
    fill="none"
    stroke="currentColor"
    viewBox="0 0 24 24"
  >
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"
    />
  </svg>
);

const SpinnerIcon = () => (
  <svg className="w-4 h-4 animate-spin" viewBox="0 0 24 24" fill="none">
    <circle
      className="opacity-25"
      cx="12"
      cy="12"
      r="10"
      stroke="currentColor"
      strokeWidth="4"
    />
    <path
      className="opacity-75"
      fill="currentColor"
      d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"
    />
  </svg>
);

const FileTextIcon = () => (
  <svg
    className="w-4 h-4"
    fill="none"
    stroke="currentColor"
    viewBox="0 0 24 24"
  >
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
    />
  </svg>
);

export default function AgreementPDFButton({
  leaseId,
  generatedBy,
  variant = "primary",
  className = "",
}: AgreementPDFButtonProps) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = async () => {
    setLoading(true);
    setError(null);

    try {
      // 1. Dynamically import jsPDF (avoids SSR issues)
      const { downloadAgreementPDF: dlPDF } =
        await import("@/lib/generateAgreementPDF");

      // 2. Fetch full lease data from your existing API
      const res = await fetch(`/api/leases/${leaseId}`);
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data?.error || "Failed to load lease data");
      }

      const { lease } = await res.json();

      if (!lease) throw new Error("Lease not found");

      // 3. Build AgreementData from your Mongoose document shape
      const tenant = lease.tenantId; // populated
      const units = lease.unitIds; // populated array

      // Format dates
      const fmt = (d: string | Date | null | undefined) => {
        if (!d) return "";
        return new Date(d).toLocaleDateString("en-GB", {
          day: "2-digit",
          month: "long",
          year: "numeric",
        });
      };

      const agreementData: AgreementData = {
        // Landlord / Building
        buildingName: "Mridha Villa 2",
        landlordName: "Mridha Family",
        landlordAddress: "Mridha Villa 2, Bangladesh", // Update with real address
        landlordPhone: "",

        // Tenant
        tenantName: tenant?.name ?? "N/A",
        tenantPhone: tenant?.phone ?? "N/A",
        tenantNID: tenant?.nidNumber ?? undefined,
        tenantAddress: tenant?.permanentAddress ?? undefined,
        tenantGuardianName: tenant?.guardianName ?? undefined,

        // Units
        unitNames: Array.isArray(units)
          ? units.map((u: any) => u?.unitName ?? u)
          : [],
        unitTypes: Array.isArray(units)
          ? units.map((u: any) => u?.unitType ?? "unit")
          : [],
        floorOrLocation:
          Array.isArray(units) && units[0]?.floorOrLocation
            ? units[0].floorOrLocation
            : undefined,

        // Lease financial terms
        monthlyRent: lease.monthlyRent ?? 0,
        advanceAmount: lease.advanceAmount ?? 0,
        securityDeposit: lease.securityDeposit ?? undefined,
        paymentDueDay: lease.rentDueDay ?? 10,
        gracePeriodDays: lease.gracePeriodDays ?? undefined,

        // Lease dates
        leaseStartDate: fmt(lease.startDate),
        leaseEndDate: lease.endDate ? fmt(lease.endDate) : undefined,

        // Utilities
        electricityIncluded: lease.includesElectricity ?? true,
        gasIncluded: lease.includesGas ?? false,
        waterIncluded: true, // water is always building expense per your rules

        // Agreement meta
        agreementDate: fmt(lease.startDate) || fmt(new Date().toISOString()),
        agreementNumber: `MVA-${lease._id?.toString().slice(-6).toUpperCase()}`,
        witnessName1: undefined,
        witnessName2: undefined,

        generatedBy,
      };

      // 4. Generate & download
      dlPDF(agreementData);
    } catch (err: any) {
      console.error("PDF generation error:", err);
      setError(err.message || "Failed to generate PDF");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col gap-1">
      <button
        onClick={handleGenerate}
        disabled={loading}
        className={`${variants[variant]} ${className}`}
        title="Download Rental Agreement PDF"
      >
        {loading ? (
          <>
            <SpinnerIcon />
            Generating PDF...
          </>
        ) : (
          <>
            <FileTextIcon />
            Agreement Deed
            <DownloadIcon />
          </>
        )}
      </button>

      {error && <p className="text-xs text-red-500 mt-1">{error}</p>}
    </div>
  );
}
