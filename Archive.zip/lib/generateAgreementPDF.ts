/**
 * generateAgreementPDF.ts
 *
 * Client-side PDF generation for Rental Agreement Deed.
 * Uses jsPDF (no server needed, works perfectly on Vercel).
 *
 * Install: npm install jspdf
 */

import jsPDF from "jspdf";

export interface AgreementData {
  // Building / Landlord
  buildingName: string;
  landlordName: string;
  landlordAddress: string;
  landlordPhone?: string;

  // Tenant
  tenantName: string;
  tenantPhone: string;
  tenantNID?: string;
  tenantAddress?: string;
  tenantGuardianName?: string;

  // Unit(s)
  unitNames: string[]; // e.g. ["Shop 5", "Shop 6"]
  unitTypes: string[]; // e.g. ["shop", "shop"]
  floorOrLocation?: string;

  // Lease terms
  leaseStartDate: string; // formatted string e.g. "01 January 2025"
  leaseEndDate?: string;
  monthlyRent: number; // total BDT
  advanceAmount: number; // BDT
  securityDeposit?: number; // BDT
  paymentDueDay: number; // e.g. 10
  gracePeriodDays?: number;

  // Utilities
  electricityIncluded: boolean;
  gasIncluded: boolean;
  waterIncluded: boolean;

  // Agreement meta
  agreementDate: string; // formatted string
  agreementNumber?: string;
  witnessName1?: string;
  witnessName2?: string;

  // Who generated
  generatedBy: string;
}

/**
 * Formats a BDT amount as "৳1,000" style.
 */
function formatBDT(amount: number): string {
  return "\u09F3" + amount.toLocaleString("en-IN");
}

/**
 * Word-wraps text to fit within maxWidth using jsPDF's getTextWidth.
 */
function wrapText(doc: jsPDF, text: string, maxWidth: number): string[] {
  return doc.splitTextToSize(text, maxWidth);
}

/**
 * Draws a horizontal rule.
 */
function drawHR(
  doc: jsPDF,
  y: number,
  margin: number,
  pageWidth: number,
  color: [number, number, number] = [180, 180, 180],
): number {
  doc.setDrawColor(...color);
  doc.setLineWidth(0.3);
  doc.line(margin, y, pageWidth - margin, y);
  return y + 4;
}

/**
 * Draws a section heading with background.
 */
function drawSectionHeading(
  doc: jsPDF,
  title: string,
  y: number,
  margin: number,
  pageWidth: number,
): number {
  const contentWidth = pageWidth - margin * 2;
  doc.setFillColor(30, 58, 138); // indigo-900
  doc.rect(margin, y, contentWidth, 8, "F");
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(10);
  doc.setFont("helvetica", "bold");
  doc.text(title.toUpperCase(), margin + 4, y + 5.5);
  doc.setTextColor(0, 0, 0);
  return y + 12;
}

/**
 * Draws a two-column label-value row.
 */
function drawRow(
  doc: jsPDF,
  label: string,
  value: string,
  y: number,
  margin: number,
  pageWidth: number,
  zebra: boolean = false,
): number {
  const contentWidth = pageWidth - margin * 2;
  const colWidth = contentWidth / 2;

  if (zebra) {
    doc.setFillColor(248, 250, 252);
    doc.rect(margin, y - 3.5, contentWidth, 7, "F");
  }

  doc.setFontSize(9);
  doc.setFont("helvetica", "bold");
  doc.setTextColor(71, 85, 105); // slate-600
  doc.text(label, margin + 2, y);

  doc.setFont("helvetica", "normal");
  doc.setTextColor(15, 23, 42); // slate-950
  const wrapped = wrapText(doc, value || "—", colWidth - 4);
  doc.text(wrapped, margin + colWidth, y);

  const lineHeight = Math.max(7, wrapped.length * 5);
  return y + lineHeight;
}

/**
 * Draws a clause paragraph with numbering.
 */
function drawClause(
  doc: jsPDF,
  number: number,
  title: string,
  body: string,
  y: number,
  margin: number,
  pageWidth: number,
  checkPageBreak: (currentY: number) => number,
): number {
  y = checkPageBreak(y);

  const contentWidth = pageWidth - margin * 2;

  doc.setFontSize(9.5);
  doc.setFont("helvetica", "bold");
  doc.setTextColor(30, 58, 138);
  doc.text(`${number}. ${title}`, margin, y);
  y += 6;

  doc.setFont("helvetica", "normal");
  doc.setTextColor(30, 41, 59);
  const lines = wrapText(doc, body, contentWidth - 6);
  lines.forEach((line: string) => {
    y = checkPageBreak(y);
    doc.text(line, margin + 6, y);
    y += 5;
  });

  return y + 3;
}

/**
 * Main PDF generation function.
 * Returns the jsPDF instance (call .save() or .output() on it).
 */
export function generateAgreementPDF(data: AgreementData): jsPDF {
  const doc = new jsPDF({
    orientation: "portrait",
    unit: "mm",
    format: "a4",
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 18;
  let y = 0;

  // Track pages
  let pageNumber = 1;

  /**
   * Adds a footer to the current page.
   */
  const addFooter = () => {
    const footerY = pageHeight - 10;
    doc.setDrawColor(200, 200, 200);
    doc.setLineWidth(0.2);
    doc.line(margin, footerY - 3, pageWidth - margin, footerY - 3);

    doc.setFontSize(7.5);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(148, 163, 184);
    doc.text(
      `${data.buildingName} — Rental Agreement — ${data.agreementDate}`,
      margin,
      footerY,
    );
    doc.text(`Page ${pageNumber}`, pageWidth - margin, footerY, {
      align: "right",
    });
    if (data.agreementNumber) {
      doc.text(`Ref: ${data.agreementNumber}`, pageWidth / 2, footerY, {
        align: "center",
      });
    }
  };

  /**
   * Checks if we need a new page; adds footer + new page if so.
   */
  const checkPageBreak = (
    currentY: number,
    requiredSpace: number = 20,
  ): number => {
    if (currentY + requiredSpace > pageHeight - 20) {
      addFooter();
      doc.addPage();
      pageNumber++;
      return 20;
    }
    return currentY;
  };

  // ─────────────────────────────────────────────
  // HEADER / TITLE BLOCK
  // ─────────────────────────────────────────────
  y = 15;

  // Top border stripe
  doc.setFillColor(30, 58, 138);
  doc.rect(0, 0, pageWidth, 5, "F");

  // Building name
  doc.setFontSize(22);
  doc.setFont("helvetica", "bold");
  doc.setTextColor(30, 58, 138);
  doc.text(data.buildingName, pageWidth / 2, y + 8, { align: "center" });

  y += 14;
  doc.setFontSize(9);
  doc.setFont("helvetica", "normal");
  doc.setTextColor(100, 116, 139);
  doc.text(data.landlordAddress, pageWidth / 2, y, { align: "center" });

  y += 5;
  if (data.landlordPhone) {
    doc.text(`Phone: ${data.landlordPhone}`, pageWidth / 2, y, {
      align: "center",
    });
    y += 5;
  }

  y += 3;
  y = drawHR(doc, y, margin, pageWidth, [30, 58, 138]);

  // Document title
  doc.setFontSize(15);
  doc.setFont("helvetica", "bold");
  doc.setTextColor(15, 23, 42);
  doc.text("RENTAL AGREEMENT DEED", pageWidth / 2, y + 7, { align: "center" });

  y += 10;
  doc.setFontSize(8.5);
  doc.setFont("helvetica", "normal");
  doc.setTextColor(100, 116, 139);
  doc.text(`Date: ${data.agreementDate}`, pageWidth / 2, y + 4, {
    align: "center",
  });
  if (data.agreementNumber) {
    doc.text(`Agreement No: ${data.agreementNumber}`, pageWidth / 2, y + 9, {
      align: "center",
    });
    y += 5;
  }

  y += 12;
  y = drawHR(doc, y, margin, pageWidth);

  // ─────────────────────────────────────────────
  // PARTIES INTRODUCTION
  // ─────────────────────────────────────────────
  y += 4;
  doc.setFontSize(9);
  doc.setFont("helvetica", "normal");
  doc.setTextColor(30, 41, 59);

  const introText =
    `This Rental Agreement ("Agreement") is entered into on ${data.agreementDate}, between ` +
    `${data.landlordName} ("Landlord"), the owner of ${data.buildingName}, ` +
    `located at ${data.landlordAddress}, and ${data.tenantName} ("Tenant"). ` +
    `Both parties agree to the terms and conditions set forth in this Agreement.`;

  const introLines = wrapText(doc, introText, pageWidth - margin * 2);
  introLines.forEach((line: string) => {
    doc.text(line, margin, y);
    y += 5;
  });

  y += 5;

  // ─────────────────────────────────────────────
  // SECTION 1 — LANDLORD DETAILS
  // ─────────────────────────────────────────────
  y = drawSectionHeading(
    doc,
    "Section 1 — Landlord Details",
    y,
    margin,
    pageWidth,
  );
  let zebra = false;
  y = drawRow(doc, "Full Name", data.landlordName, y, margin, pageWidth, zebra);
  zebra = !zebra;
  y = drawRow(
    doc,
    "Address",
    data.landlordAddress,
    y,
    margin,
    pageWidth,
    zebra,
  );
  zebra = !zebra;
  if (data.landlordPhone) {
    y = drawRow(doc, "Phone", data.landlordPhone, y, margin, pageWidth, zebra);
    zebra = !zebra;
  }
  y += 4;

  // ─────────────────────────────────────────────
  // SECTION 2 — TENANT DETAILS
  // ─────────────────────────────────────────────
  y = checkPageBreak(y, 40);
  y = drawSectionHeading(
    doc,
    "Section 2 — Tenant Details",
    y,
    margin,
    pageWidth,
  );
  zebra = false;
  y = drawRow(doc, "Full Name", data.tenantName, y, margin, pageWidth, zebra);
  zebra = !zebra;
  y = drawRow(
    doc,
    "Phone Number",
    data.tenantPhone,
    y,
    margin,
    pageWidth,
    zebra,
  );
  zebra = !zebra;
  if (data.tenantNID) {
    y = drawRow(doc, "NID Number", data.tenantNID, y, margin, pageWidth, zebra);
    zebra = !zebra;
  }
  if (data.tenantAddress) {
    y = drawRow(
      doc,
      "Permanent Address",
      data.tenantAddress,
      y,
      margin,
      pageWidth,
      zebra,
    );
    zebra = !zebra;
  }
  if (data.tenantGuardianName) {
    y = drawRow(
      doc,
      "Father's / Guardian's Name",
      data.tenantGuardianName,
      y,
      margin,
      pageWidth,
      zebra,
    );
    zebra = !zebra;
  }
  y += 4;

  // ─────────────────────────────────────────────
  // SECTION 3 — PROPERTY DETAILS
  // ─────────────────────────────────────────────
  y = checkPageBreak(y, 45);
  y = drawSectionHeading(
    doc,
    "Section 3 — Property Details",
    y,
    margin,
    pageWidth,
  );
  zebra = false;
  y = drawRow(doc, "Building", data.buildingName, y, margin, pageWidth, zebra);
  zebra = !zebra;
  y = drawRow(
    doc,
    "Rented Unit(s)",
    data.unitNames.join(", "),
    y,
    margin,
    pageWidth,
    zebra,
  );
  zebra = !zebra;
  y = drawRow(
    doc,
    "Unit Type(s)",
    data.unitTypes
      .map((t) => t.charAt(0).toUpperCase() + t.slice(1))
      .join(", "),
    y,
    margin,
    pageWidth,
    zebra,
  );
  zebra = !zebra;
  if (data.floorOrLocation) {
    y = drawRow(
      doc,
      "Floor / Location",
      data.floorOrLocation,
      y,
      margin,
      pageWidth,
      zebra,
    );
    zebra = !zebra;
  }
  y = drawRow(
    doc,
    "Full Address",
    data.landlordAddress,
    y,
    margin,
    pageWidth,
    zebra,
  );
  zebra = !zebra;
  y += 4;

  // ─────────────────────────────────────────────
  // SECTION 4 — FINANCIAL TERMS
  // ─────────────────────────────────────────────
  y = checkPageBreak(y, 55);
  y = drawSectionHeading(
    doc,
    "Section 4 — Financial Terms",
    y,
    margin,
    pageWidth,
  );
  zebra = false;
  y = drawRow(
    doc,
    "Monthly Rent",
    formatBDT(data.monthlyRent),
    y,
    margin,
    pageWidth,
    zebra,
  );
  zebra = !zebra;
  y = drawRow(
    doc,
    "Advance / Deposit Paid",
    formatBDT(data.advanceAmount),
    y,
    margin,
    pageWidth,
    zebra,
  );
  zebra = !zebra;
  if (data.securityDeposit) {
    y = drawRow(
      doc,
      "Security Deposit",
      formatBDT(data.securityDeposit),
      y,
      margin,
      pageWidth,
      zebra,
    );
    zebra = !zebra;
  }
  y = drawRow(
    doc,
    "Payment Due Date",
    `On or before the ${data.paymentDueDay}${getOrdinal(data.paymentDueDay)} of each month`,
    y,
    margin,
    pageWidth,
    zebra,
  );
  zebra = !zebra;
  if (data.gracePeriodDays) {
    y = drawRow(
      doc,
      "Grace Period",
      `${data.gracePeriodDays} days after due date`,
      y,
      margin,
      pageWidth,
      zebra,
    );
    zebra = !zebra;
  }
  y += 4;

  // ─────────────────────────────────────────────
  // SECTION 5 — LEASE DURATION
  // ─────────────────────────────────────────────
  y = checkPageBreak(y, 30);
  y = drawSectionHeading(
    doc,
    "Section 5 — Lease Duration",
    y,
    margin,
    pageWidth,
  );
  zebra = false;
  y = drawRow(
    doc,
    "Lease Start Date",
    data.leaseStartDate,
    y,
    margin,
    pageWidth,
    zebra,
  );
  zebra = !zebra;
  if (data.leaseEndDate) {
    y = drawRow(
      doc,
      "Lease End Date",
      data.leaseEndDate,
      y,
      margin,
      pageWidth,
      zebra,
    );
    zebra = !zebra;
  } else {
    y = drawRow(
      doc,
      "Lease Duration",
      "Month-to-month (rolling)",
      y,
      margin,
      pageWidth,
      zebra,
    );
    zebra = !zebra;
  }
  y += 4;

  // ─────────────────────────────────────────────
  // SECTION 6 — UTILITIES
  // ─────────────────────────────────────────────
  y = checkPageBreak(y, 30);
  y = drawSectionHeading(doc, "Section 6 — Utilities", y, margin, pageWidth);
  zebra = false;
  y = drawRow(
    doc,
    "Electricity",
    data.electricityIncluded
      ? "Paid by Tenant (sub-meter reading)"
      : "Not applicable",
    y,
    margin,
    pageWidth,
    zebra,
  );
  zebra = !zebra;
  y = drawRow(
    doc,
    "Gas",
    data.gasIncluded ? "Paid by Tenant" : "Not applicable",
    y,
    margin,
    pageWidth,
    zebra,
  );
  zebra = !zebra;
  y = drawRow(
    doc,
    "Water",
    data.waterIncluded
      ? "Included in rent / Building expense"
      : "Building expense",
    y,
    margin,
    pageWidth,
    zebra,
  );
  zebra = !zebra;
  y += 4;

  // ─────────────────────────────────────────────
  // SECTION 7 — TERMS & CONDITIONS
  // ─────────────────────────────────────────────
  y = checkPageBreak(y, 20);
  y = drawSectionHeading(
    doc,
    "Section 7 — Terms & Conditions",
    y,
    margin,
    pageWidth,
  );
  y += 3;

  const clauses: Array<{ title: string; body: string }> = [
    {
      title: "Rent Payment",
      body: `The Tenant agrees to pay a monthly rent of ${formatBDT(data.monthlyRent)} (Bangladesh Taka) on or before the ${data.paymentDueDay}${getOrdinal(data.paymentDueDay)} day of each calendar month. Late payment may incur penalties as decided by the Landlord.`,
    },
    {
      title: "Advance Amount",
      body: `The Tenant has paid an advance amount of ${formatBDT(data.advanceAmount)} at the time of signing this agreement. This advance will be adjusted against future rent obligations or refunded (minus any dues) upon vacation of the premises.`,
    },
    {
      title: "Electricity & Utilities",
      body: data.electricityIncluded
        ? "The Tenant shall pay electricity charges based on sub-meter readings at the applicable rate per unit (kWh) as notified by the Landlord each month. Utility bills must be paid along with or before the monthly rent."
        : "Utility arrangements shall be separately agreed upon between the Landlord and Tenant.",
    },
    {
      title: "Property Use",
      body: `The rented premises (${data.unitNames.join(", ")}) shall be used solely for lawful ${data.unitTypes.includes("shop") ? "commercial/business" : "residential"} purposes. The Tenant shall not sublet, transfer, or assign the premises without prior written consent of the Landlord.`,
    },
    {
      title: "Maintenance & Repairs",
      body: "The Tenant shall maintain the rented premises in a clean and sanitary condition. Minor repairs and upkeep are the Tenant's responsibility. Major structural repairs are the Landlord's responsibility unless caused by the Tenant's negligence.",
    },
    {
      title: "Alterations",
      body: "The Tenant shall not make any structural alterations, additions, or modifications to the premises without prior written permission from the Landlord. Any approved alterations shall become part of the property unless otherwise agreed.",
    },
    {
      title: "Inspection",
      body: "The Landlord or their authorized representative reserves the right to inspect the rented premises at reasonable times with prior notice to the Tenant.",
    },
    {
      title: "Termination & Notice",
      body: "Either party may terminate this agreement by providing at least 30 (thirty) days written notice to the other party. The Tenant must vacate the premises and return the keys on or before the last day of the notice period.",
    },
    {
      title: "Damages & Liability",
      body: "The Tenant shall be liable for any damage to the property caused by the Tenant, their family members, employees, or visitors. The cost of repair or replacement shall be deducted from the advance or recovered separately.",
    },
    {
      title: "Prohibited Activities",
      body: "The Tenant shall not engage in any illegal activities, cause nuisance to neighbors, or violate any applicable laws or regulations while occupying the premises. Violation of this clause constitutes grounds for immediate termination.",
    },
    {
      title: "Force Majeure",
      body: "Neither party shall be held liable for failure to perform obligations due to events beyond their reasonable control, including natural disasters, government actions, or other force majeure events.",
    },
    {
      title: "Governing Law",
      body: "This Agreement shall be governed by the laws of the People's Republic of Bangladesh. Any disputes arising out of this Agreement shall be resolved amicably, and if necessary, through the appropriate courts having jurisdiction.",
    },
  ];

  clauses.forEach((clause, index) => {
    y = drawClause(
      doc,
      index + 1,
      clause.title,
      clause.body,
      y,
      margin,
      pageWidth,
      checkPageBreak,
    );
    y += 2;
  });

  // ─────────────────────────────────────────────
  // SECTION 8 — SIGNATURE BLOCK
  // ─────────────────────────────────────────────
  y = checkPageBreak(y, 70);
  y += 5;
  y = drawSectionHeading(doc, "Section 8 — Signatures", y, margin, pageWidth);
  y += 6;

  const contentWidth = pageWidth - margin * 2;
  const colW = contentWidth / 2;

  doc.setFontSize(9);
  doc.setFont("helvetica", "bold");
  doc.setTextColor(30, 41, 59);
  doc.text("LANDLORD", margin + colW * 0.25, y, { align: "center" });
  doc.text("TENANT", margin + colW + colW * 0.25, y, { align: "center" });

  y += 20;

  // Signature lines
  doc.setDrawColor(0, 0, 0);
  doc.setLineWidth(0.4);
  doc.line(margin, y, margin + colW * 0.5, y);
  doc.line(margin + colW, y, margin + colW + colW * 0.5, y);

  y += 5;
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8.5);
  doc.setTextColor(71, 85, 105);
  doc.text(data.landlordName, margin, y);
  doc.text("Signature", margin + colW * 0.55, y);
  doc.text(data.tenantName, margin + colW, y);
  doc.text("Signature", margin + colW + colW * 0.55, y);

  y += 5;
  doc.setTextColor(100, 116, 139);
  doc.text("(Landlord)", margin, y);
  doc.text("(Tenant)", margin + colW, y);

  y += 10;
  doc.setFontSize(8.5);
  doc.setTextColor(100, 116, 139);
  doc.text(`Date: ${data.agreementDate}`, margin, y);
  doc.text(`Date: ${data.agreementDate}`, margin + colW, y);

  // ─────────────────────────────────────────────
  // WITNESSES (if provided)
  // ─────────────────────────────────────────────
  if (data.witnessName1 || data.witnessName2) {
    y += 14;
    y = checkPageBreak(y, 40);

    doc.setFontSize(9);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(30, 41, 59);
    doc.text("WITNESSES", margin, y);
    y += 3;
    y = drawHR(doc, y, margin, pageWidth);
    y += 10;

    if (data.witnessName1) {
      doc.setLineWidth(0.4);
      doc.line(margin, y, margin + 60, y);
      y += 5;
      doc.setFont("helvetica", "normal");
      doc.setFontSize(8.5);
      doc.setTextColor(71, 85, 105);
      doc.text(`1. ${data.witnessName1}`, margin, y);
      y += 10;
    }

    if (data.witnessName2) {
      doc.setLineWidth(0.4);
      doc.line(margin, y, margin + 60, y);
      y += 5;
      doc.setFont("helvetica", "normal");
      doc.setFontSize(8.5);
      doc.setTextColor(71, 85, 105);
      doc.text(`2. ${data.witnessName2}`, margin, y);
      y += 10;
    }
  }

  // ─────────────────────────────────────────────
  // GENERATED NOTE
  // ─────────────────────────────────────────────
  y = checkPageBreak(y, 20);
  y += 8;
  doc.setFontSize(7.5);
  doc.setFont("helvetica", "italic");
  doc.setTextColor(148, 163, 184);
  doc.text(
    `This document was generated on ${new Date().toLocaleString("en-BD")} by ${data.generatedBy} via ${data.buildingName} Management System.`,
    pageWidth / 2,
    y,
    { align: "center" },
  );

  // Add footer to last page
  addFooter();

  return doc;
}

/**
 * Triggers a browser download of the PDF.
 */
export function downloadAgreementPDF(
  data: AgreementData,
  filename?: string,
): void {
  const doc = generateAgreementPDF(data);
  const safeName = (data.tenantName || "tenant")
    .replace(/\s+/g, "_")
    .toLowerCase();
  const safeUnit = data.unitNames.join("-").replace(/\s+/g, "_").toLowerCase();
  const defaultFilename = `agreement_${safeName}_${safeUnit}_${data.agreementDate.replace(/\s+/g, "_")}.pdf`;
  doc.save(filename || defaultFilename);
}

// ─── Helpers ───────────────────────────────────────────────
function getOrdinal(n: number): string {
  const s = ["th", "st", "nd", "rd"];
  const v = n % 100;
  return s[(v - 20) % 10] || s[v] || s[0];
}
